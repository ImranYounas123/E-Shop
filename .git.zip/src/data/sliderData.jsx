const sliderData = [
    {
      imgUrl: slider1,
      title: 'Charge your phone safty',
      description:
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, urna eu tincidunt consectetur, nisi nunc pretium nisl, euismod.',
      shopUrl: '#',
      productUrl: '#',
    },
    {
      imgUrl: slider2,
      title: 'Get new cover from it',
      description:
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, urna eu tincidunt consectetur, nisi nunc pretium nisl, euismod.',
      shopUrl: '#',
      productUrl: '#',
    },
    {
      imgUrl: slider3,
      title: 'New phone cover from it',
      description:
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, urna eu tincidunt consectetur, nisi nunc pretium nisl, euismod.',
      shopUrl: '#',
      productUrl: '#',
    },
  ];
  
  export default sliderData;